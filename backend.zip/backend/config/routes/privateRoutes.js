const privateRoutes = {
  'GET /users': 'UserController.getAll',
};

module.exports = privateRoutes;
